# Cadastro de Usuário (Flutter)

Tela de cadastro de usuário desenvolvida em Flutter, com captura de dados, filtros de entrada, validação por campo e feedback visual ao usuário.

## Campos

| Campo         | Regra                                   |
|---------------|-----------------------------------------|
| Nome completo | Obrigatório, texto livre                |
| E-mail        | Obrigatório, deve conter `@`            |
| CPF           | Obrigatório, somente números (11 dígitos) |
| Telefone      | Obrigatório, somente números (10 ou 11 dígitos) |
| Senha         | Obrigatória, mínimo de 6 caracteres     |

## Comportamento

- O botão **CADASTRAR** dispara a validação do formulário.
- Os erros aparecem logo abaixo de cada campo inválido.
- Com todos os campos válidos, um `SnackBar` de sucesso é exibido.

## Conceitos aplicados

- `Form` com `GlobalKey<FormState>`
- `TextFormField` com `validator`
- `keyboardType` e `inputFormatters` (`FilteringTextInputFormatter.digitsOnly`, `LengthLimitingTextInputFormatter`)
- `SingleChildScrollView` para evitar overflow com o teclado
- `ScaffoldMessenger` + `SnackBar`

## Estrutura da tela

```
Scaffold
└── Form(key: _formKey)
    └── SingleChildScrollView
        └── Column
            ├── TextFormField (nome)
            ├── TextFormField (e-mail)
            ├── TextFormField (CPF)
            ├── TextFormField (telefone)
            ├── TextFormField (senha)
            └── ElevatedButton (CADASTRAR)
```

## Como executar

```bash
flutter create .      # gera as pastas de plataforma (android, ios, web...)
flutter pub get
flutter run
```
